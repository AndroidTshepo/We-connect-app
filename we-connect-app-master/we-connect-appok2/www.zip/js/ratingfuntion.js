
var getRatingNumber = 0;
var getRatingQuestionId =0;




function processRating(val, attrVal){
          console.log(val);
		  getRatingQuestionId =$("#rating_star_textoption").text();
		  getRatingNumber= val
		  return val;
    } 